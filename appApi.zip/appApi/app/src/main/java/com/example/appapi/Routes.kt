package com.example.appapi

object Routes {
    private const val BASE_URL = "https://makeup-api.herokuapp.com/api/"
    const val POSTS = "$BASE_URL/v1/products.json?brand=maybelline"
}